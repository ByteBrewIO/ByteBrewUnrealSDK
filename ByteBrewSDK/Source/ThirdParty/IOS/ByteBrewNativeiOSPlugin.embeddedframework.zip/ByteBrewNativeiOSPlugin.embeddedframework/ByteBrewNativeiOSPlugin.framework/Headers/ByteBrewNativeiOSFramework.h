//
//  ByteBrewNativeiOSFramework.h
//  ByteBrewNativeiOSFramework
//
//  Created by Cameron Hozouri on 4/8/24.
//

#import <Foundation/Foundation.h>

//! Project version number for ByteBrewNativeiOSFramework.
FOUNDATION_EXPORT double ByteBrewNativeiOSFrameworkVersionNumber;

//! Project version string for ByteBrewNativeiOSFramework.
FOUNDATION_EXPORT const unsigned char ByteBrewNativeiOSFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ByteBrewNativeiOSFramework/PublicHeader.h>
#import <ByteBrewNativeiOSPlugin/ByteBrewNativeiOSPlugin.h>

